import { ReactNode } from "react";
import { TableProps } from "./tables";

export const Mytables: TableProps[] = [
  {
    id: 1,
    status: "available",
  },
  {
    id: 2,
    status: "available",
  },
  {
    id: 3,
    status: "available",
  },
  {
    id: 4,
    status: "available",
  },
  {
    id: 5,
    status: "available",
  },
  {
    id: 6,
    status: "available",
  },
  {
    id: 7,
    status: "available",
  },
  {
    id: 8,
    status: "available",
  },
  {
    id: 9,
    status: "available",
  },
  {
    id: 10,
    status: "available",
  },
  {
    id: 11,
    status: "available",
  },
  {
    id: 12,
    status: "available",
  },
  {
    id: 13,
    status: "available",
  },
  {
    id: 14,
    status: "available",
  },
  {
    id: 15,
    status: "available",
  },
  {
    id: 16,
    status: "available",
  },
];
