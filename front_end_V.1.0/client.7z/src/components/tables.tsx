import "../index.css";
import "../sass/bootstrap.scss";
import "../sass/font-awesome.scss";
import { ReactNode } from "react";

export type TableProps = {
  id: string;
  status: string;
  onClickOrder: (id: string, status: string) => void;
};
export default function Table({ id, status, onClickOrder }: TableProps) {
  return (
    <>
      <div
        onClick={() => onClickOrder(id, status)}
        className={`table border border-dark  ${
          status === "available"
            ? "table-available"
            : "table-unavailabe fa-regular"
        }`}
      >
        <div className="h5 text-center">{id}</div>
      </div>
    </>
  );
}
